import 'package:flutter/material.dart';
import '../core/responsive.dart';
import '../widgets/primary_button.dart';
import 'package:url_launcher/url_launcher.dart';

class Header extends StatelessWidget implements PreferredSizeWidget {
  const Header({super.key});

  // Daftar menu + anchor id (nanti dipakai ScrollController kalau mau smooth-scroll)
  static final List<(String text, String id)> _menus = [
    ('Home', 'home'),
    ('About', 'about'),
    ('Process', 'process'),
    ('Experience', 'experience'),
    ('Portfolio', 'portfolio'),
    ('Skills', 'skills'),
    ('Blog', 'blog'),
    ('Services', 'services'),
  ];

  @override
  Size get preferredSize => const Size.fromHeight(70);

  @override
  Widget build(BuildContext context) {
    return Responsive.isDesktop(context)
        ? _DesktopHeader(menus: _menus)
        : _MobileHeader(menus: _menus);
  }
}

/* ---------- DESKTOP ---------- */

class _DesktopHeader extends StatelessWidget {
  final List<(String, String)> menus;
  const _DesktopHeader({required this.menus});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.white.withOpacity(0.9),
      elevation: 0,
      titleSpacing: 32,
      title: Row(
        children: [
          const CircleAvatar(
            radius: 18,
            backgroundColor: Color(0xFF7B3FFF),
            child: Text('N', style: TextStyle(color: Colors.white)),
          ),
          const SizedBox(width: 10),
          Text(
            'Nemanja',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
        ],
      ),
      actions: [
        for (final item in menus)
          TextButton(
            onPressed: () {
              // TODO: panggil ScrollController.animateTo() berdasarkan item.$2
            },
            child: Text(item.$1),
          ),
        const SizedBox(width: 12),
        Padding(
          padding: const EdgeInsets.only(right: 32),
          child: PrimaryButton(
            label: 'Contact',
            onPressed: () =>
                launchUrl(Uri.parse('mailto:hello@yourdomain.com')),
          ),
        ),
      ],
    );
  }
}

/* ---------- MOBILE ---------- */

class _MobileHeader extends StatelessWidget {
  final List<(String, String)> menus;
  const _MobileHeader({required this.menus});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.white,
      elevation: 1,
      title: Row(
        children: [
          const CircleAvatar(
            radius: 16,
            backgroundColor: Color(0xFF7B3FFF),
            child: Text('N', style: TextStyle(color: Colors.white)),
          ),
          const SizedBox(width: 8),
          const Text('Nemanja', style: TextStyle(color: Colors.black87)),
        ],
      ),
      iconTheme: const IconThemeData(color: Colors.black87),
      actions: [
        PopupMenuButton<String>(
          icon: const Icon(Icons.menu),
          onSelected: (value) {
            // TODO: smooth-scroll ke section sesuai value
            if (value == 'contact') {
              launchUrl(Uri.parse('mailto:hello@yourdomain.com'));
            }
          },
          itemBuilder: (context) => [
            ...menus.map((e) => PopupMenuItem(value: e.$2, child: Text(e.$1))),
            const PopupMenuDivider(),
            const PopupMenuItem(value: 'contact', child: Text('Contact')),
          ],
        ),
      ],
    );
  }
}
