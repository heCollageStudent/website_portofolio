import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

final route = GoRouter(
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) =>
          HomePage(initialSection: state.queryParameters['s']),
    ),
    GoRoute(path: '/blog', builder: (context, state) => const BlogPage()),
    GoRoute(
      path: '/portfolio',
      builder: (context, state) => const PortfolioPage(),
    ),
  ],
  errorBuilder: (_, _) => const Scaffold(body: Center(child: Text('404'))),
);
